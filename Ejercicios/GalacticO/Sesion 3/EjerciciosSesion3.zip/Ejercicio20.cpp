#include <iostream>
#include <cmath>
using namespace std;

int main()
{
	const double pi1 = 256.0 / 81.0;
	const double pi2 = 3 + 1.0/8.0;
	const double pi3 = 377.0 / 120.0;
	cout << "Valores de pi:  \n" << pi1 << "\n" << pi2 << "\n" << pi3;
}
