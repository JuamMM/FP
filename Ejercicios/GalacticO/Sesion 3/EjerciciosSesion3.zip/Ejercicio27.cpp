#include <iostream>
#include <cmath>
using namespace std;


int main()
{
	int edad;
	double producto_neto;
	bool primo;
	char estado_civil;
	char sexo;
}
